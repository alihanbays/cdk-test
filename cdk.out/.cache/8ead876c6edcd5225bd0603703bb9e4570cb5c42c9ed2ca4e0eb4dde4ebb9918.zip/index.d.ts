export declare const handler: (event: {
    name: string;
}) => Promise<string>;
